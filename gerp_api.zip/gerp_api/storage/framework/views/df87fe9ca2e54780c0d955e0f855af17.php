

<?php $__env->startSection('content'); ?>

<div class="container-fluid py-4">

    

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h4 class="mb-1">Style Details</h4>

            <p class="text-muted mb-0">
                View complete style information
            </p>
        </div>

        <div class="d-flex gap-2">

            <a href="<?php echo e(route('styles.edit', $style->id)); ?>"
               class="btn btn-primary">

                <i class="bi bi-pencil me-1"></i>
                Edit Style

            </a>

            <a href="<?php echo e(route('styles.index')); ?>"
               class="btn btn-light border">

                <i class="bi bi-arrow-left me-1"></i>
                Back

            </a>

        </div>

    </div>


    

    <?php if(session('success')): ?>

        <div class="alert alert-success alert-dismissible fade show">

            <i class="bi bi-check-circle me-1"></i>

            <?php echo e(session('success')); ?>


            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>

        </div>

    <?php endif; ?>


    

    <?php if($errors->any()): ?>

        <div class="alert alert-danger alert-dismissible fade show">

            <strong>
                Please fix the following errors:
            </strong>

            <ul class="mb-0 mt-2">

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>

        </div>

    <?php endif; ?>


    

    <div class="row g-4">

        

        <div class="col-lg-8">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white py-3">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <h5 class="mb-0">
                                Style Information
                            </h5>

                            <small class="text-muted">
                                Style #<?php echo e($style->style_no); ?>

                            </small>

                        </div>

                        <?php if($style->status === 'active'): ?>

                            <span class="badge bg-success-subtle text-success px-3 py-2">

                                <i class="bi bi-check-circle me-1"></i>
                                Active

                            </span>

                        <?php else: ?>

                            <span class="badge bg-secondary-subtle text-secondary px-3 py-2">

                                <i class="bi bi-x-circle me-1"></i>
                                Inactive

                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="card-body">

                    <div class="row g-4">

                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Style Name
                            </div>

                            <div class="fw-semibold">
                                <?php echo e($style->style_name); ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Style No
                            </div>

                            <div class="fw-semibold">
                                <?php echo e($style->style_no); ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Buyer
                            </div>

                            <?php if($style->buyer): ?>

                                <div class="fw-semibold">
                                    <?php echo e($style->buyer->name); ?>

                                </div>

                                <?php if($style->buyer->company_name): ?>

                                    <div class="text-muted small">
                                        <?php echo e($style->buyer->company_name); ?>

                                    </div>

                                <?php endif; ?>

                            <?php else: ?>

                                <span class="text-muted">
                                    No buyer assigned
                                </span>

                            <?php endif; ?>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Season
                            </div>

                            <div class="fw-semibold">
                                <?php echo e($style->season ?: 'N/A'); ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Status
                            </div>

                            <?php if($style->status === 'active'): ?>

                                <span class="badge bg-success-subtle text-success">
                                    Active
                                </span>

                            <?php else: ?>

                                <span class="badge bg-secondary-subtle text-secondary">
                                    Inactive
                                </span>

                            <?php endif; ?>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                ID
                            </div>

                            <div class="fw-semibold">
                                #<?php echo e($style->id); ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Created At
                            </div>

                            <div>
                                <?php echo e($style->created_at?->format('d M Y, h:i A') ?? 'N/A'); ?>

                            </div>

                        </div>


                        <div class="col-md-6">

                            <div class="text-muted small mb-1">
                                Last Updated
                            </div>

                            <div>
                                <?php echo e($style->updated_at?->format('d M Y, h:i A') ?? 'N/A'); ?>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        

        <div class="col-lg-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white py-3">

                    <h5 class="mb-0">
                        Quick Actions
                    </h5>

                </div>


                <div class="card-body">

                    <div class="d-grid gap-2">

                        <a href="<?php echo e(route('styles.edit', $style->id)); ?>"
                           class="btn btn-primary">

                            <i class="bi bi-pencil me-1"></i>
                            Edit Style

                        </a>


                        <form
                            action="<?php echo e(route('styles.destroy', $style->id)); ?>"
                            method="POST"
                            onsubmit="return confirm('Are you sure you want to delete this style?');"
                        >

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit"
                                    class="btn btn-outline-danger w-100">

                                <i class="bi bi-trash me-1"></i>
                                Delete Style

                            </button>

                        </form>


                        <a href="<?php echo e(route('styles.index')); ?>"
                           class="btn btn-light border">

                            <i class="bi bi-list me-1"></i>
                            All Styles

                        </a>

                    </div>

                </div>

            </div>


            

            <?php if($style->buyer): ?>

                <div class="card border-0 shadow-sm mt-4">

                    <div class="card-header bg-white py-3">

                        <h5 class="mb-0">
                            Buyer Information
                        </h5>

                    </div>


                    <div class="card-body">

                        <div class="mb-3">

                            <div class="text-muted small">
                                Buyer Name
                            </div>

                            <div class="fw-semibold">
                                <?php echo e($style->buyer->name); ?>

                            </div>

                        </div>


                        <?php if($style->buyer->company_name): ?>

                            <div class="mb-3">

                                <div class="text-muted small">
                                    Company
                                </div>

                                <div>
                                    <?php echo e($style->buyer->company_name); ?>

                                </div>

                            </div>

                        <?php endif; ?>


                        <?php if($style->buyer->email): ?>

                            <div class="mb-3">

                                <div class="text-muted small">
                                    Email
                                </div>

                                <div>
                                    <?php echo e($style->buyer->email); ?>

                                </div>

                            </div>

                        <?php endif; ?>


                        <?php if($style->buyer->phone): ?>

                            <div>

                                <div class="text-muted small">
                                    Phone
                                </div>

                                <div>
                                    <?php echo e($style->buyer->phone); ?>

                                </div>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endif; ?>

        </div>

    </div>


    

    <div class="card border-0 shadow-sm mt-4">

        <div class="card-header bg-white py-3">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <h5 class="mb-1">

                        <i class="bi bi-file-earmark-text me-1"></i>

                        Tech Packs

                    </h5>

                    <small class="text-muted">
                        Technical information, images and PDF documents
                    </small>

                </div>


                <a href="#add-tech-pack"
                   class="btn btn-primary btn-sm">

                    <i class="bi bi-plus-lg me-1"></i>
                    Add Tech Pack

                </a>

            </div>

        </div>


        <div class="card-body">

            

            <?php if($style->techPacks && $style->techPacks->count()): ?>

                <div class="row g-4">

                    <?php $__currentLoopData = $style->techPacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $techPack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-12">

                            <div class="border rounded p-3">

                                <div class="row g-4">

                                    

                                    <div class="col-md-3">

                                        <?php if($techPack->image_path): ?>

                                            <div class="border rounded overflow-hidden bg-light">

                                                <a
                                                    href="<?php echo e(asset('storage/' . $techPack->image_path)); ?>"
                                                    target="_blank"
                                                >

                                                    <img
                                                        src="<?php echo e(asset('storage/' . $techPack->image_path)); ?>"
                                                        alt="Tech Pack Image"
                                                        class="img-fluid w-100"
                                                        style="height:220px; object-fit:cover;"
                                                    >

                                                </a>

                                            </div>

                                        <?php else: ?>

                                            <div
                                                class="border rounded bg-light d-flex align-items-center justify-content-center"
                                                style="height:220px;"
                                            >

                                                <div class="text-center text-muted">

                                                    <i class="bi bi-image fs-1"></i>

                                                    <div class="small mt-2">
                                                        No Image
                                                    </div>

                                                </div>

                                            </div>

                                        <?php endif; ?>

                                    </div>


                                    

                                    <div class="col-md-5">

                                        <div class="d-flex justify-content-between align-items-start">

                                            <div>

                                                <h5 class="mb-1">
                                                    <?php echo e($techPack->tech_pack_no); ?>

                                                </h5>

                                                <div class="text-muted small">

                                                    Version:
                                                    <?php echo e($techPack->version); ?>


                                                </div>

                                            </div>


                                            <?php if($techPack->status === 'approved'): ?>

                                                <span class="badge bg-success-subtle text-success">
                                                    Approved
                                                </span>

                                            <?php elseif($techPack->status === 'pending'): ?>

                                                <span class="badge bg-warning-subtle text-warning">
                                                    Pending
                                                </span>

                                            <?php elseif($techPack->status === 'rejected'): ?>

                                                <span class="badge bg-danger-subtle text-danger">
                                                    Rejected
                                                </span>

                                            <?php else: ?>

                                                <span class="badge bg-secondary-subtle text-secondary">
                                                    Draft
                                                </span>

                                            <?php endif; ?>

                                        </div>


                                        <hr>


                                        <div class="row g-3">

                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    Product Type
                                                </div>

                                                <div class="fw-semibold">
                                                    <?php echo e($techPack->product_type ?: 'N/A'); ?>

                                                </div>

                                            </div>


                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    Fabric
                                                </div>

                                                <div class="fw-semibold">
                                                    <?php echo e($techPack->fabric ?: 'N/A'); ?>

                                                </div>

                                            </div>


                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    GSM
                                                </div>

                                                <div class="fw-semibold">
                                                    <?php echo e($techPack->gsm ?: 'N/A'); ?>

                                                </div>

                                            </div>


                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    Color
                                                </div>

                                                <div class="fw-semibold">
                                                    <?php echo e($techPack->color ?: 'N/A'); ?>

                                                </div>

                                            </div>


                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    Size Range
                                                </div>

                                                <div class="fw-semibold">
                                                    <?php echo e($techPack->size_range ?: 'N/A'); ?>

                                                </div>

                                            </div>


                                            <div class="col-sm-6">

                                                <div class="text-muted small">
                                                    Created
                                                </div>

                                                <div>
                                                    <?php echo e($techPack->created_at?->format('d M Y') ?? 'N/A'); ?>

                                                </div>

                                            </div>

                                        </div>


                                        <?php if($techPack->notes): ?>

                                            <div class="mt-3">

                                                <div class="text-muted small">
                                                    Notes
                                                </div>

                                                <div>
                                                    <?php echo e($techPack->notes); ?>

                                                </div>

                                            </div>

                                        <?php endif; ?>

                                    </div>


                                    

                                    <div class="col-md-4">

                                        <div class="border rounded p-3 bg-light h-100">

                                            <h6 class="mb-3">

                                                <i class="bi bi-paperclip me-1"></i>
                                                Documents

                                            </h6>


                                            <?php if($techPack->file_path): ?>

                                                <div class="d-flex align-items-center mb-3">

                                                    <i class="bi bi-file-earmark-pdf text-danger fs-3 me-2"></i>

                                                    <div>

                                                        <div class="fw-semibold">
                                                            Tech Pack PDF
                                                        </div>

                                                        <small class="text-muted">
                                                            PDF Document
                                                        </small>

                                                    </div>

                                                </div>


                                                <div class="d-grid gap-2">

                                                    <a
                                                        href="<?php echo e(asset('storage/' . $techPack->file_path)); ?>"
                                                        target="_blank"
                                                        class="btn btn-danger btn-sm"
                                                    >

                                                        <i class="bi bi-eye me-1"></i>
                                                        Preview PDF

                                                    </a>


                                                    <a
                                                        href="<?php echo e(asset('storage/' . $techPack->file_path)); ?>"
                                                        download
                                                        class="btn btn-outline-secondary btn-sm"
                                                    >

                                                        <i class="bi bi-download me-1"></i>
                                                        Download PDF

                                                    </a>

                                                </div>

                                            <?php else: ?>

                                                <div class="text-muted small mb-3">

                                                    <i class="bi bi-file-earmark-x me-1"></i>

                                                    No PDF uploaded.

                                                </div>

                                            <?php endif; ?>


                                            <hr>


                                            <div class="d-flex gap-2">

                                                <a
                                                    href="<?php echo e(route('tech-packs.show', $techPack->id)); ?>"
                                                    class="btn btn-sm btn-light border flex-fill"
                                                >

                                                    <i class="bi bi-eye me-1"></i>
                                                    View

                                                </a>


                                                <a
                                                    href="<?php echo e(route('tech-packs.edit', $techPack->id)); ?>"
                                                    class="btn btn-sm btn-light border flex-fill"
                                                >

                                                    <i class="bi bi-pencil me-1"></i>
                                                    Edit

                                                </a>

                                            </div>


                                            <form
                                                action="<?php echo e(route('tech-packs.destroy', $techPack->id)); ?>"
                                                method="POST"
                                                class="mt-2"
                                                onsubmit="return confirm('Are you sure you want to delete this Tech Pack?');"
                                            >

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button
                                                    type="submit"
                                                    class="btn btn-outline-danger btn-sm w-100"
                                                >

                                                    <i class="bi bi-trash me-1"></i>
                                                    Delete Tech Pack

                                                </button>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php else: ?>

                <div class="text-center py-4">

                    <i class="bi bi-file-earmark-text fs-1 text-muted"></i>

                    <h6 class="mt-3">
                        No Tech Pack Found
                    </h6>

                    <p class="text-muted mb-0">
                        Add the first Tech Pack for this style.
                    </p>

                </div>

            <?php endif; ?>


            

            <div
                id="add-tech-pack"
                class="border rounded mt-4 p-4 bg-light"
            >

                <div class="mb-4">

                    <h5 class="mb-1">

                        <i class="bi bi-plus-circle me-1"></i>
                        Add Tech Pack

                    </h5>

                    <p class="text-muted mb-0">
                        Add technical specifications, image and PDF.
                    </p>

                </div>


                <form
                    id="techPackForm"
                    action="<?php echo e(route('tech-packs.store')); ?>"
                    method="POST"
                    enctype="multipart/form-data"
                >

                    <?php echo csrf_field(); ?>

                    <input
                        type="hidden"
                        name="style_id"
                        value="<?php echo e($style->id); ?>"
                    >


                    <div class="row g-3">

                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Tech Pack No
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="tech_pack_no"
                                class="form-control <?php $__errorArgs = ['tech_pack_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('tech_pack_no')); ?>"
                                placeholder="Example: TP-001"
                                required
                            >

                            <?php $__errorArgs = ['tech_pack_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>


                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Version
                                <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                name="version"
                                class="form-control <?php $__errorArgs = ['version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('version', '1.0')); ?>"
                                placeholder="Example: 1.0"
                                required
                            >

                            <?php $__errorArgs = ['version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>


                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Product Type
                            </label>

                            <input
                                type="text"
                                name="product_type"
                                class="form-control"
                                value="<?php echo e(old('product_type')); ?>"
                                placeholder="Example: T-Shirt"
                            >

                        </div>


                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Fabric
                            </label>

                            <input
                                type="text"
                                name="fabric"
                                class="form-control"
                                value="<?php echo e(old('fabric')); ?>"
                                placeholder="Example: 100% Cotton"
                            >

                        </div>


                        

                        <div class="col-md-4">

                            <label class="form-label">
                                GSM
                            </label>

                            <input
                                type="text"
                                name="gsm"
                                class="form-control"
                                value="<?php echo e(old('gsm')); ?>"
                                placeholder="Example: 180 GSM"
                            >

                        </div>


                        

                        <div class="col-md-4">

                            <label class="form-label">
                                Color
                            </label>

                            <input
                                type="text"
                                name="color"
                                class="form-control"
                                value="<?php echo e(old('color')); ?>"
                                placeholder="Example: Navy Blue"
                            >

                        </div>


                        

                        <div class="col-md-4">

                            <label class="form-label">
                                Size Range
                            </label>

                            <input
                                type="text"
                                name="size_range"
                                class="form-control"
                                value="<?php echo e(old('size_range')); ?>"
                                placeholder="Example: S - XXL"
                            >

                        </div>


                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Construction
                            </label>

                            <textarea
                                name="construction"
                                class="form-control"
                                rows="3"
                                placeholder="Construction details..."
                            ><?php echo e(old('construction')); ?></textarea>

                        </div>


                        

                        <div class="col-md-6">

                            <label class="form-label">
                                Washing
                            </label>

                            <textarea
                                name="washing"
                                class="form-control"
                                rows="3"
                                placeholder="Washing instructions..."
                            ><?php echo e(old('washing')); ?></textarea>

                        </div>


                        

                        <div class="col-md-4">

                            <label class="form-label">

                                Status
                                <span class="text-danger">*</span>

                            </label>

                            <select
                                name="status"
                                class="form-select"
                                required
                            >

                                <option value="draft"
                                    <?php echo e(old('status', 'draft') === 'draft' ? 'selected' : ''); ?>>
                                    Draft
                                </option>

                                <option value="pending"
                                    <?php echo e(old('status') === 'pending' ? 'selected' : ''); ?>>
                                    Pending
                                </option>

                                <option value="approved"
                                    <?php echo e(old('status') === 'approved' ? 'selected' : ''); ?>>
                                    Approved
                                </option>

                                <option value="rejected"
                                    <?php echo e(old('status') === 'rejected' ? 'selected' : ''); ?>>
                                    Rejected
                                </option>

                            </select>

                        </div>


                        

                        <div class="col-md-4">

                            <label for="techPackImage"
                                   class="form-label">

                                Tech Pack Image

                            </label>

                            <input
                                type="file"
                                name="image"
                                id="techPackImage"
                                class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            >

                            <small class="text-muted">
                                JPG, JPEG, PNG, WEBP — Maximum 20MB
                            </small>

                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div id="imageClientError"
                                 class="text-danger small mt-1 d-none">
                            </div>

                        </div>


                        

                        <div class="col-md-4">

                            <label for="techPackPdf"
                                   class="form-label">

                                Tech Pack PDF

                            </label>

                            <input
                                type="file"
                                name="pdf"
                                id="techPackPdf"
                                class="form-control <?php $__errorArgs = ['pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                accept=".pdf,application/pdf"
                            >

                            <small class="text-muted">
                                PDF only — Maximum 20MB
                            </small>

                            <?php $__errorArgs = ['pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div id="pdfClientError"
                                 class="text-danger small mt-1 d-none">
                            </div>

                        </div>


                        

                        <div class="col-md-6">

                            <div id="imagePreviewContainer"
                                 class="d-none">

                                <label class="form-label">
                                    Image Preview
                                </label>

                                <div class="border rounded p-2 bg-white">

                                    <img
                                        id="imagePreview"
                                        src=""
                                        alt="Image Preview"
                                        class="img-fluid rounded"
                                        style="max-height:250px; width:100%; object-fit:contain;"
                                    >

                                </div>

                            </div>

                        </div>


                        

                        <div class="col-md-6">

                            <div id="pdfPreviewContainer"
                                 class="d-none">

                                <label class="form-label">
                                    Selected PDF
                                </label>

                                <div class="border rounded p-3 bg-white">

                                    <div class="d-flex align-items-center">

                                        <i class="bi bi-file-earmark-pdf text-danger fs-2 me-2"></i>

                                        <div>

                                            <div id="pdfFileName"
                                                 class="fw-semibold">
                                            </div>

                                            <small id="pdfFileSize"
                                                   class="text-muted">
                                            </small>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>


                        

                        <div class="col-12">

                            <label class="form-label">
                                Notes
                            </label>

                            <textarea
                                name="notes"
                                class="form-control"
                                rows="3"
                                placeholder="Additional notes..."
                            ><?php echo e(old('notes')); ?></textarea>

                        </div>


                        

                        <div class="col-12">

                            <hr>

                            <div class="d-flex justify-content-end gap-2">

                                <button
                                    type="reset"
                                    class="btn btn-light border"
                                    id="resetTechPackBtn"
                                >

                                    <i class="bi bi-arrow-counterclockwise me-1"></i>
                                    Reset

                                </button>


                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                    id="saveTechPackBtn"
                                >

                                    <i class="bi bi-save me-1"></i>
                                    Save Tech Pack

                                </button>

                            </div>

                        </div>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>




<script>

document.addEventListener('DOMContentLoaded', function () {

    const MAX_IMAGE_SIZE = 20 * 1024 * 1024;
    const MAX_PDF_SIZE   = 20 * 1024 * 1024;

    const imageInput = document.getElementById('techPackImage');
    const imagePreview = document.getElementById('imagePreview');
    const imageContainer = document.getElementById('imagePreviewContainer');
    const imageClientError = document.getElementById('imageClientError');

    const pdfInput = document.getElementById('techPackPdf');
    const pdfContainer = document.getElementById('pdfPreviewContainer');
    const pdfFileName = document.getElementById('pdfFileName');
    const pdfFileSize = document.getElementById('pdfFileSize');
    const pdfClientError = document.getElementById('pdfClientError');

    const form = document.getElementById('techPackForm');
    const submitButton = document.getElementById('saveTechPackBtn');
    const resetButton = document.getElementById('resetTechPackBtn');


    function formatFileSize(bytes)
    {
        if (bytes < 1024) {
            return bytes + ' B';
        }

        if (bytes < 1024 * 1024) {
            return (bytes / 1024).toFixed(2) + ' KB';
        }

        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }


    /*
    |--------------------------------------------------------------------------
    | IMAGE UPLOAD
    |--------------------------------------------------------------------------
    */

    if (imageInput) {

        imageInput.addEventListener('change', function () {

            const file = imageInput.files[0];

            imageClientError.classList.add('d-none');
            imageClientError.textContent = '';

            imageContainer.classList.add('d-none');
            imagePreview.src = '';


            if (!file) {
                return;
            }


            const allowedTypes = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];


            if (!allowedTypes.includes(file.type)) {

                imageClientError.textContent =
                    'Please select a JPG, JPEG, PNG or WEBP image.';

                imageClientError.classList.remove('d-none');

                imageInput.value = '';

                return;
            }


            if (file.size > MAX_IMAGE_SIZE) {

                imageClientError.textContent =
                    'Image is too large. Maximum allowed size is 20MB.';

                imageClientError.classList.remove('d-none');

                imageInput.value = '';

                return;
            }


            const reader = new FileReader();


            reader.onload = function (event) {

                imagePreview.src = event.target.result;

                imageContainer.classList.remove('d-none');

            };


            reader.onerror = function () {

                imageClientError.textContent =
                    'Unable to preview this image. Please choose another image.';

                imageClientError.classList.remove('d-none');

            };


            reader.readAsDataURL(file);

        });

    }


    /*
    |--------------------------------------------------------------------------
    | PDF UPLOAD
    |--------------------------------------------------------------------------
    */

    if (pdfInput) {

        pdfInput.addEventListener('change', function () {

            const file = pdfInput.files[0];

            pdfClientError.classList.add('d-none');
            pdfClientError.textContent = '';

            pdfContainer.classList.add('d-none');
            pdfFileName.textContent = '';
            pdfFileSize.textContent = '';


            if (!file) {
                return;
            }


            if (
                file.type !== 'application/pdf' &&
                !file.name.toLowerCase().endsWith('.pdf')
            ) {

                pdfClientError.textContent =
                    'Please select a valid PDF file.';

                pdfClientError.classList.remove('d-none');

                pdfInput.value = '';

                return;
            }


            if (file.size > MAX_PDF_SIZE) {

                pdfClientError.textContent =
                    'PDF is too large. Maximum allowed size is 20MB.';

                pdfClientError.classList.remove('d-none');

                pdfInput.value = '';

                return;
            }


            pdfFileName.textContent = file.name;

            pdfFileSize.textContent =
                formatFileSize(file.size);


            pdfContainer.classList.remove('d-none');

        });

    }


    /*
    |--------------------------------------------------------------------------
    | FORM SUBMIT VALIDATION
    |--------------------------------------------------------------------------
    */

    if (form) {

        form.addEventListener('submit', function (event) {

            let hasError = false;


            if (imageInput && imageInput.files.length > 0) {

                const imageFile = imageInput.files[0];

                if (imageFile.size > MAX_IMAGE_SIZE) {

                    event.preventDefault();

                    imageClientError.textContent =
                        'Image is too large. Maximum allowed size is 20MB.';

                    imageClientError.classList.remove('d-none');

                    hasError = true;
                }

            }


            if (pdfInput && pdfInput.files.length > 0) {

                const pdfFile = pdfInput.files[0];

                if (pdfFile.size > MAX_PDF_SIZE) {

                    event.preventDefault();

                    pdfClientError.textContent =
                        'PDF is too large. Maximum allowed size is 20MB.';

                    pdfClientError.classList.remove('d-none');

                    hasError = true;
                }

            }


            if (hasError) {
                return;
            }


            if (submitButton) {

                submitButton.disabled = true;

                submitButton.innerHTML =
                    '<span class="spinner-border spinner-border-sm me-1"></span>' +
                    'Uploading...';

            }

        });

    }


    /*
    |--------------------------------------------------------------------------
    | RESET
    |--------------------------------------------------------------------------
    */

    if (resetButton) {

        resetButton.addEventListener('click', function () {

            setTimeout(function () {

                imageContainer.classList.add('d-none');

                imagePreview.src = '';

                imageClientError.classList.add('d-none');
                imageClientError.textContent = '';

                pdfContainer.classList.add('d-none');

                pdfFileName.textContent = '';
                pdfFileSize.textContent = '';

                pdfClientError.classList.add('d-none');
                pdfClientError.textContent = '';

                if (submitButton) {

                    submitButton.disabled = false;

                    submitButton.innerHTML =
                        '<i class="bi bi-save me-1"></i>' +
                        'Save Tech Pack';

                }

            }, 50);

        });

    }

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/styles/show.blade.php ENDPATH**/ ?>