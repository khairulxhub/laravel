

<?php $__env->startSection('content'); ?>

<div class="container-fluid">



<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h2 class="mb-1 fw-bold">Add Style</h2>
        <p class="text-muted mb-0">
            Create a new garment style
        </p>
    </div>

    <a href="<?php echo e(route('styles.index')); ?>"
       class="btn btn-light border">
        <i class="bi bi-arrow-left"></i>
        Back to Styles
    </a>

</div>



<div class="card shadow-sm border-0">

    <div class="card-header bg-white py-3">
        <h5 class="mb-0 fw-bold">
            Style Information
        </h5>
    </div>

    <div class="card-body">

        <form action="<?php echo e(route('styles.store')); ?>"
              method="POST">

            <?php echo csrf_field(); ?>

            <div class="row g-3">

                
                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Style Name
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        name="style_name"
                        class="form-control <?php $__errorArgs = ['style_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('style_name')); ?>"
                        placeholder="Enter style name"
                        required
                    >

                    <?php $__errorArgs = ['style_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Style No
                        <span class="text-danger">*</span>
                    </label>

                    <input
                        type="text"
                        name="style_no"
                        class="form-control <?php $__errorArgs = ['style_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('style_no')); ?>"
                        placeholder="Example: ST-001"
                        required
                    >

                    <?php $__errorArgs = ['style_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div class="col-md-6">

                    <label class="form-label fw-semibold">
                        Buyer
                    </label>

                    <select
                        name="buyer_id"
                        class="form-select <?php $__errorArgs = ['buyer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    >

                        <option value="">
                            Select Buyer
                        </option>

                        <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($buyer->id); ?>"
                                <?php echo e(old('buyer_id') == $buyer->id ? 'selected' : ''); ?>

                            >
                                <?php echo e($buyer->name); ?>

                            </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                    <?php $__errorArgs = ['buyer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                
                <div class="col-md-3">

                    <label class="form-label fw-semibold">
                        Season
                    </label>

                    <input
                        type="text"
                        name="season"
                        class="form-control"
                        value="<?php echo e(old('season')); ?>"
                        placeholder="Example: 2026"
                    >

                </div>


                
                <div class="col-md-3">

                    <label class="form-label fw-semibold">
                        Status
                    </label>

                    <select name="status" class="form-select">

                        <option value="active"
                            <?php echo e(old('status', 'active') == 'active' ? 'selected' : ''); ?>>
                            Active
                        </option>

                        <option value="inactive"
                            <?php echo e(old('status') == 'inactive' ? 'selected' : ''); ?>>
                            Inactive
                        </option>

                    </select>

                </div>

            </div>


            
            <div class="d-flex justify-content-end gap-2 mt-4">

                <a href="<?php echo e(route('styles.index')); ?>"
                   class="btn btn-light border">
                    Cancel
                </a>

                <button type="submit"
                        class="btn btn-primary">
                    <i class="bi bi-check-lg"></i>
                    Save Style
                </button>

            </div>

        </form>

    </div>

</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/styles/create.blade.php ENDPATH**/ ?>