

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0">

```

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 mb-1">Buyers</h1>
        <p class="text-muted mb-0">Manage all garment buyers</p>
    </div>

    <a href="<?php echo e(route('buyers.create')); ?>" class="btn btn-primary">
        <i data-feather="plus"></i>
        Add Buyer
    </a>
</div>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>


        <button type="button"
                class="btn-close"
                data-bs-dismiss="alert">
        </button>
    </div>
<?php endif; ?>


<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>


        <button type="button"
                class="btn-close"
                data-bs-dismiss="alert">
        </button>
    </div>
<?php endif; ?>


<div class="card mb-3">
    <div class="card-body">

        <form action="<?php echo e(route('buyers.index')); ?>" method="GET">

            <div class="row g-2">

                <div class="col-md-5">
                    <input
                        type="text"
                        name="search"
                        class="form-control"
                        placeholder="Search buyer, company, email or phone..."
                        value="<?php echo e(request('search')); ?>"
                    >
                </div>

                <div class="col-md-3">
                    <select name="status" class="form-select">

                        <option value="">All Status</option>

                        <option value="Active"
                            <?php echo e(request('status') == 'Active' ? 'selected' : ''); ?>>
                            Active
                        </option>

                        <option value="Inactive"
                            <?php echo e(request('status') == 'Inactive' ? 'selected' : ''); ?>>
                            Inactive
                        </option>

                    </select>
                </div>

                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i data-feather="search"></i>
                        Search
                    </button>
                </div>

                <div class="col-md-2">
                    <a href="<?php echo e(route('buyers.index')); ?>"
                       class="btn btn-light border w-100">
                        Reset
                    </a>
                </div>

            </div>

        </form>

    </div>
</div>


<div class="card">

    <div class="card-header">
        <div class="card-title mb-0">
            Buyer List
        </div>
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Buyer</th>
                        <th>Company</th>
                        <th>Contact</th>
                        <th>Country</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            
                            <td>
                                <?php echo e($buyer->id); ?>

                            </td>

                            
                            <td>
                                <strong>
                                    <?php echo e($buyer->name); ?>

                                </strong>

                                <?php if($buyer->email): ?>
                                    <div class="small text-muted">
                                        <?php echo e($buyer->email); ?>

                                    </div>
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <?php echo e($buyer->company_name ?: '-'); ?>

                            </td>

                            
                            <td>
                                <?php if($buyer->phone): ?>
                                    <div>
                                        <?php echo e($buyer->phone); ?>

                                    </div>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <?php echo e($buyer->country ?: '-'); ?>

                            </td>

                            
                            <td>

                                <?php if($buyer->status === 'Active'): ?>

                                    <span class="badge bg-success">
                                        Active
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-secondary">
                                        Inactive
                                    </span>

                                <?php endif; ?>

                            </td>

                            
                            <td class="text-end">

                                <div class="btn-group">

                                    
                                    <a href="<?php echo e(route('buyers.show', $buyer->id)); ?>"
                                       class="btn btn-sm btn-outline-info"
                                       title="View">
                                        <i data-feather="eye"></i>
                                    </a>

                                    
                                    <a href="<?php echo e(route('buyers.edit', $buyer->id)); ?>"
                                       class="btn btn-sm btn-outline-primary"
                                       title="Edit">
                                        <i data-feather="edit-2"></i>
                                    </a>

                                    
                                    <form
                                        action="<?php echo e(route('buyers.destroy', $buyer->id)); ?>"
                                        method="POST"
                                        class="d-inline"
                                        onsubmit="return confirm('Are you sure you want to delete this buyer?');"
                                    >

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-danger"
                                            title="Delete"
                                        >
                                            <i data-feather="trash-2"></i>
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="7" class="text-center py-5">

                                <div class="text-muted">

                                    <i data-feather="users"
                                       style="width:40px;height:40px;">
                                    </i>

                                    <h5 class="mt-3">
                                        No buyers found
                                    </h5>

                                    <p class="mb-3">
                                        Start by adding your first buyer.
                                    </p>

                                    <a href="<?php echo e(route('buyers.create')); ?>"
                                       class="btn btn-primary">
                                        <i data-feather="plus"></i>
                                        Add Buyer
                                    </a>

                                </div>

                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        
        <?php if($buyers->hasPages()): ?>

            <div class="d-flex justify-content-between align-items-center mt-3">

                <div class="text-muted small">
                    Showing
                    <?php echo e($buyers->firstItem()); ?>

                    to
                    <?php echo e($buyers->lastItem()); ?>

                    of
                    <?php echo e($buyers->total()); ?>

                    buyers
                </div>

                <div>
                    <?php echo e($buyers->withQueryString()->links()); ?>

                </div>

            </div>

        <?php endif; ?>

    </div>

</div>
```

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/buyers/index.blade.php ENDPATH**/ ?>