

<?php $__env->startSection('title', 'Create Garment Order'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-3">

    <div>
        <h1 class="h3 mb-1">Create Garment Order</h1>
        <p class="text-muted mb-0">
            Add a new garment order
        </p>
    </div>

    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary">

        <i data-feather="arrow-left"></i>

        Back to Orders

    </a>

</div>


<?php if($errors->any()): ?>

    <div class="alert alert-danger">

        <strong>Please fix the following errors:</strong>

        <ul class="mb-0 mt-2">

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>

<?php endif; ?>


<div class="card">

    <div class="card-header">

        <h5 class="card-title mb-0">
            Order Information
        </h5>

    </div>


    <div class="card-body">

        <form action="<?php echo e(route('orders.store')); ?>" method="POST">

            <?php echo csrf_field(); ?>


            

            <h5 class="mb-3">
                Order Basic Information
            </h5>


            <div class="row">


                

                <div class="col-md-6 mb-3">

                    <label for="order_number" class="form-label">
                        Order Number <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           name="order_number"
                           id="order_number"
                           class="form-control <?php $__errorArgs = ['order_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('order_number')); ?>"
                           placeholder="GERP-2026-0001"
                           required>

                    <?php $__errorArgs = ['order_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-6 mb-3">

                    <label for="po_number" class="form-label">
                        PO Number
                    </label>

                    <input type="text"
                           name="po_number"
                           id="po_number"
                           class="form-control <?php $__errorArgs = ['po_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('po_number')); ?>"
                           placeholder="PO-ABC-2026-091">

                    <?php $__errorArgs = ['po_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-6 mb-3">

                    <label for="buyer_name" class="form-label">
                        Buyer Name <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           name="buyer_name"
                           id="buyer_name"
                           class="form-control <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('buyer_name')); ?>"
                           placeholder="ABC Fashion International"
                           required>

                    <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-6 mb-3">

                    <label for="order_type" class="form-label">
                        Order Type
                    </label>

                    <select name="order_type"
                            id="order_type"
                            class="form-select <?php $__errorArgs = ['order_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                        <option value="">Select Order Type</option>

                        <option value="FOB"
                            <?php echo e(old('order_type') == 'FOB' ? 'selected' : ''); ?>>
                            FOB
                        </option>

                        <option value="CM"
                            <?php echo e(old('order_type') == 'CM' ? 'selected' : ''); ?>>
                            CM
                        </option>

                        <option value="CMT"
                            <?php echo e(old('order_type') == 'CMT' ? 'selected' : ''); ?>>
                            CMT
                        </option>

                        <option value="Export"
                            <?php echo e(old('order_type') == 'Export' ? 'selected' : ''); ?>>
                            Export
                        </option>

                    </select>

                    <?php $__errorArgs = ['order_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-6 mb-3">

                    <label for="style_number" class="form-label">
                        Style Number
                    </label>

                    <input type="text"
                           name="style_number"
                           id="style_number"
                           class="form-control <?php $__errorArgs = ['style_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('style_number')); ?>"
                           placeholder="ST-POLO-2601">

                    <?php $__errorArgs = ['style_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-6 mb-3">

                    <label for="product_name" class="form-label">
                        Product Name <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           name="product_name"
                           id="product_name"
                           class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('product_name')); ?>"
                           placeholder="Men's Premium Polo Shirt"
                           required>

                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

            </div>


            <hr class="my-4">


            

            <h5 class="mb-3">
                Quantity & Price
            </h5>


            <div class="row">


                

                <div class="col-md-4 mb-3">

                    <label for="order_qty" class="form-label">
                        Order Quantity <span class="text-danger">*</span>
                    </label>

                    <input type="number"
                           name="order_qty"
                           id="order_qty"
                           class="form-control <?php $__errorArgs = ['order_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('order_qty')); ?>"
                           min="1"
                           placeholder="50000"
                           required>

                    <?php $__errorArgs = ['order_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-4 mb-3">

                    <label for="unit_price" class="form-label">
                        Unit Price ($) <span class="text-danger">*</span>
                    </label>

                    <input type="number"
                           name="unit_price"
                           id="unit_price"
                           class="form-control <?php $__errorArgs = ['unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('unit_price')); ?>"
                           min="0"
                           step="0.01"
                           placeholder="6.25"
                           required>

                    <?php $__errorArgs = ['unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-4 mb-3">

                    <label for="total_value" class="form-label">
                        Total Value ($)
                    </label>

                    <input type="number"
                           name="total_value"
                           id="total_value"
                           class="form-control"
                           value="<?php echo e(old('total_value')); ?>"
                           step="0.01"
                           readonly>

                    <small class="text-muted">
                        Automatically calculated
                    </small>

                </div>

            </div>


            <hr class="my-4">


            

            <h5 class="mb-3">
                Order Schedule
            </h5>


            <div class="row">


                

                <div class="col-md-4 mb-3">

                    <label for="order_date" class="form-label">
                        Order Date <span class="text-danger">*</span>
                    </label>

                    <input type="date"
                           name="order_date"
                           id="order_date"
                           class="form-control <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('order_date', date('Y-m-d'))); ?>"
                           required>

                    <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-4 mb-3">

                    <label for="ex_factory_date" class="form-label">
                        Ex-Factory Date
                    </label>

                    <input type="date"
                           name="ex_factory_date"
                           id="ex_factory_date"
                           class="form-control <?php $__errorArgs = ['ex_factory_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('ex_factory_date')); ?>">

                    <?php $__errorArgs = ['ex_factory_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>


                

                <div class="col-md-4 mb-3">

                    <label for="status" class="form-label">
                        Status <span class="text-danger">*</span>
                    </label>

                    <select name="status"
                            id="status"
                            class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required>

                        <option value="Pending"
                            <?php echo e(old('status', 'Pending') == 'Pending' ? 'selected' : ''); ?>>
                            Pending
                        </option>

                        <option value="In Progress"
                            <?php echo e(old('status') == 'In Progress' ? 'selected' : ''); ?>>
                            In Progress
                        </option>

                        <option value="Completed"
                            <?php echo e(old('status') == 'Completed' ? 'selected' : ''); ?>>
                            Completed
                        </option>

                        <option value="Cancelled"
                            <?php echo e(old('status') == 'Cancelled' ? 'selected' : ''); ?>>
                            Cancelled
                        </option>

                    </select>

                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

            </div>


            

            <div class="mb-3">

                <label for="notes" class="form-label">
                    Notes
                </label>

                <textarea name="notes"
                          id="notes"
                          rows="4"
                          class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          placeholder="Enter any additional order notes..."><?php echo e(old('notes')); ?></textarea>

                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            

            <div class="d-flex justify-content-end gap-2 mt-4">

                <a href="<?php echo e(route('orders.index')); ?>"
                   class="btn btn-secondary">

                    Cancel

                </a>

                <button type="submit"
                        class="btn btn-primary">

                    <i data-feather="save"></i>

                    Save Order

                </button>

            </div>


        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>

    document.addEventListener('DOMContentLoaded', function () {

        const orderQty = document.getElementById('order_qty');
        const unitPrice = document.getElementById('unit_price');
        const totalValue = document.getElementById('total_value');

        function calculateTotal() {

            const qty = parseFloat(orderQty.value) || 0;
            const price = parseFloat(unitPrice.value) || 0;

            const total = qty * price;

            totalValue.value = total.toFixed(2);

        }

        orderQty.addEventListener('input', calculateTotal);

        unitPrice.addEventListener('input', calculateTotal);

        calculateTotal();

    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/orders/create.blade.php ENDPATH**/ ?>