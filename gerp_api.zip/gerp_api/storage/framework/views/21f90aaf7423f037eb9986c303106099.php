

<?php $__env->startSection('title', 'Garment Orders'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 mb-1">Garment Orders</h1>
        <p class="text-muted mb-0">Manage all garment orders</p>
    </div>
<div class="d-flex align-items-center gap-2 mb-3">

    

    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">
        <i class="align-middle" data-feather="plus"></i>
        Add Order
    </a>

</div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>


        <button type="button"
                class="btn-close"
                data-bs-dismiss="alert">
        </button>
    </div>
<?php endif; ?>

<div class="card">

    <div class="card-header">
        <h5 class="card-title mb-0">Order List</h5>
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-hover table-bordered align-middle">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Order No</th>
                        <th>PO No</th>
                        <th>Buyer</th>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Total Value</th>
                        <th>Status</th>
                        <th width="180">Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td>
                                <?php echo e($loop->iteration + ($orders->currentPage() - 1) * $orders->perPage()); ?>

                            </td>

                            <td>
                                <strong>
                                    <?php echo e($order->order_number); ?>

                                </strong>
                            </td>

                            <td>
                                <?php echo e($order->po_number ?? '-'); ?>

                            </td>

                            <td>
                                <?php echo e($order->buyer_name); ?>

                            </td>

                            <td>
                                <?php echo e($order->product_name); ?>

                            </td>

                            <td>
                                <?php echo e(number_format($order->order_qty)); ?>

                            </td>

                            <td>
                                $<?php echo e(number_format($order->unit_price, 2)); ?>

                            </td>

                            <td>
                                <strong>
                                    $<?php echo e(number_format($order->total_value, 2)); ?>

                                </strong>
                            </td>

                            <td>

                                <?php if($order->status == 'Pending'): ?>

                                    <span class="badge bg-warning">
                                        Pending
                                    </span>

                                <?php elseif($order->status == 'In Progress'): ?>

                                    <span class="badge bg-primary">
                                        In Progress
                                    </span>

                                <?php elseif($order->status == 'Completed'): ?>

                                    <span class="badge bg-success">
                                        Completed
                                    </span>

                                <?php elseif($order->status == 'Cancelled'): ?>

                                    <span class="badge bg-danger">
                                        Cancelled
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-secondary">
                                        <?php echo e($order->status); ?>

                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>

                                <a href="<?php echo e(route('orders.show', $order->id)); ?>"
                                   class="btn btn-sm btn-info"
                                   title="View">

                                    <i data-feather="eye"></i>

                                </a>

                                <a href="<?php echo e(route('orders.edit', $order->id)); ?>"
                                   class="btn btn-sm btn-warning"
                                   title="Edit">

                                    <i data-feather="edit-2"></i>

                                </a>

                                <form action="<?php echo e(route('orders.destroy', $order->id)); ?>"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Are you sure you want to delete this order?');">

                                    <?php echo csrf_field(); ?>

                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit"
                                            class="btn btn-sm btn-danger"
                                            title="Delete">

                                        <i data-feather="trash-2"></i>

                                    </button>

                                </form>

                            </td>

                        </tr>
                        

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="10" class="text-center py-5">

                                <div class="text-muted">
                                    No garment orders found.
                                </div>
                               
                                <a href="<?php echo e(route('orders.create')); ?>"
                                   class="btn btn-primary mt-3">

                                    Add First Order

                                </a>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <?php if($orders->hasPages()): ?>

            <div class="mt-3">

                <?php echo e($orders->links()); ?>


            </div>

        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>