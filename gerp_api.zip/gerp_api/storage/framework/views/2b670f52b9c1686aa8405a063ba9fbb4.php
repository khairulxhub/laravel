<nav id="sidebar" class="sidebar js-sidebar">

    <div class="sidebar-content js-simplebar">

        
        
        

        <a class="sidebar-brand" href="/index">

            <span class="align-middle">
                Garments ERP
            </span>

        </a>


        <ul class="sidebar-nav">

            
            
            

            <li class="sidebar-item">
                <a class="sidebar-link" href="/dashboard">

                    <i class="align-middle"
                       data-feather="sliders"></i>

                    <span class="align-middle">
                        Dashboard
                    </span>

                </a>
            </li>


            
            
            

            <li class="sidebar-header">
                Merchandising
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('buyers.index')); ?>">

                    <i class="align-middle"
                       data-feather="users"></i>

                    <span class="align-middle">
                        Buyers
                    </span>

                </a>

            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('styles.index')); ?>">

                    <i class="align-middle"
                       data-feather="layers"></i>

                    <span class="align-middle">
                        Styles
                    </span>

                </a>

            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('orders.index')); ?>">

                    <i class="align-middle"
                       data-feather="shopping-bag"></i>

                    <span class="align-middle">
                        Orders
                    </span>

                </a>

            </li>


            
            
            

            <li class="sidebar-header">
                Procurement
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('suppliers.index')); ?>">

                    <i class="align-middle"
                       data-feather="truck"></i>

                    <span class="align-middle">
                        Suppliers
                    </span>

                </a>

            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('purchase-orders.index')); ?>">

                    <i class="align-middle"
                       data-feather="file-text"></i>

                    <span class="align-middle">
                        Purchase Orders
                    </span>

                </a>

            </li>


            
            
            

            <li class="sidebar-header">
                Inventory
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('materials.index')); ?>">

                    <i class="align-middle"
                       data-feather="package"></i>

                    <span class="align-middle">
                        Materials
                    </span>

                </a>

            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('stock-movements.index')); ?>">

                    <i class="align-middle"
                       data-feather="repeat"></i>

                    <span class="align-middle">
                        Stock Movements
                    </span>

                </a>

            </li>


            
            
            

            <li class="sidebar-header">
                Production
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('productions.index')); ?>">

                    <i class="align-middle"
                       data-feather="settings"></i>

                    <span class="align-middle">
                        Productions
                    </span>

                </a>

            </li>


            
            
            

            <li class="sidebar-header">
                Shipping
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('shipments.index')); ?>">

                    <i class="align-middle"
                       data-feather="send"></i>

                    <span class="align-middle">
                        Shipments
                    </span>

                </a>

            </li>


            
            
            

            <li class="sidebar-header">
                Administration
            </li>


            

            <li class="sidebar-item">

                <a class="sidebar-link"
                   href="<?php echo e(route('users.index')); ?>">

                    <i class="align-middle"
                       data-feather="user"></i>

                    <span class="align-middle">
                        Users
                    </span>

                </a>

            </li>


        </ul>

    </div>

</nav><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>