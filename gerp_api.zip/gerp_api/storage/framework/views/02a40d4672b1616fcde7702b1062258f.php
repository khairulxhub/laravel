

<?php $__env->startSection('content'); ?>

<div class="container-fluid">


<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1 fw-bold">Styles</h2>
        <p class="text-muted mb-0">Manage all garment styles</p>
    </div>

    <a href="<?php echo e(route('styles.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i>
        Add Style
    </a>
</div>



<div class="card shadow-sm border-0 mb-4">
    <div class="card-body">

        <form action="<?php echo e(route('styles.index')); ?>" method="GET">

            <div class="row g-3 align-items-end">

                
                <div class="col-md-5">
                    <label class="form-label fw-semibold">
                        Search Style
                    </label>

                    <input
                        type="text"
                        name="search"
                        class="form-control"
                        placeholder="Search style name or style no..."
                        value="<?php echo e(request('search')); ?>"
                    >
                </div>


                
                <div class="col-md-3">
                    <label class="form-label fw-semibold">
                        Status
                    </label>

                    <select name="status" class="form-select">

                        <option value="">All Status</option>

                        <option value="active"
                            <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>
                            Active
                        </option>

                        <option value="inactive"
                            <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>
                            Inactive
                        </option>

                    </select>
                </div>


                
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i>
                        Search
                    </button>
                </div>


                
                <div class="col-md-2">
                    <a href="<?php echo e(route('styles.index')); ?>"
                       class="btn btn-light border w-100">
                        <i class="bi bi-arrow-clockwise"></i>
                        Reset
                    </a>
                </div>

            </div>

        </form>

    </div>
</div>



<div class="card shadow-sm border-0">

    <div class="card-header bg-white border-0 py-3">

        <div class="d-flex justify-content-between align-items-center">

            <h5 class="mb-0 fw-bold">
                Style List
            </h5>

            <span class="text-muted">
                Total:
                <strong><?php echo e($styles->total()); ?></strong>
            </span>

        </div>

    </div>


    <div class="card-body p-0">

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                    <tr>
                        <th class="ps-4">#</th>
                        <th>Style Name</th>
                        <th>Style No</th>
                        <th>Buyer</th>
                        <th>Season</th>
                        <th>Status</th>
                        <th class="text-center">Action</th>
                    </tr>

                </thead>


                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            
                            <td class="ps-4">
                                <?php echo e($styles->firstItem() + $key); ?>

                            </td>


                            
                            <td>
                                <div class="fw-semibold">
                                    <?php echo e($style->style_name); ?>

                                </div>
                            </td>


                            
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?php echo e($style->style_no); ?>

                                </span>
                            </td>


                            
                            <td>
                                <?php echo e($style->buyer->name ?? '-'); ?>

                            </td>


                            
                            <td>
                                <?php echo e($style->season ?? '-'); ?>

                            </td>


                            
                            <td>

                                <?php if($style->status === 'active'): ?>

                                    <span class="badge bg-success-subtle text-success">
                                        <i class="bi bi-check-circle me-1"></i>
                                        Active
                                    </span>

                                <?php else: ?>

                                    <span class="badge bg-danger-subtle text-danger">
                                        <i class="bi bi-x-circle me-1"></i>
                                        Inactive
                                    </span>

                                <?php endif; ?>

                            </td>


                            
                            <td>

                                <div class="d-flex justify-content-center gap-1">

                                    
                                    <a href="<?php echo e(route('styles.show', $style->id)); ?>"
                                       class="btn btn-sm btn-light border"
                                       title="View">

                                        <i data-feather="eye"></i>

                                    </a>


                                    
                                    <a href="<?php echo e(route('styles.edit', $style->id)); ?>"
                                       class="btn btn-sm btn-light border"
                                       title="Edit">

                                        <i data-feather="edit-2"></i>

                                    </a>


                                    
                                    <form
                                        action="<?php echo e(route('styles.destroy', $style->id)); ?>"
                                        method="POST"
                                        class="d-inline"
                                        onsubmit="return confirm('Are you sure you want to delete this style?');"
                                    >

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-light border text-danger"
                                            title="Delete"
                                        >

                                            <i data-feather="trash-2"></i>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7" class="text-center py-5">

                                <div class="text-muted">

                                    <i class="bi bi-inbox fs-2 d-block mb-2"></i>

                                    <h6>No styles found</h6>

                                    <p class="mb-0">
                                        There are no garment styles available.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    
    <?php if($styles->hasPages()): ?>

        <div class="card-footer bg-white border-0">

            <div class="d-flex justify-content-end">

                <?php echo e($styles->withQueryString()->links()); ?>


            </div>

        </div>

    <?php endif; ?>

</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\Khairul-R-70-WDPF\Laravel\gerp\resources\views/admin/styles/index.blade.php ENDPATH**/ ?>